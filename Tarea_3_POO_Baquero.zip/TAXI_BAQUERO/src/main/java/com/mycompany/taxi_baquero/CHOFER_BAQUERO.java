package com.mycompany.taxi_baquero;

import java.util.Scanner;

public class CHOFER_BAQUERO extends PERSONA_BAQUERO{
public String placa;
    public String codigotaxi;
    
    public CHOFER_BAQUERO(String nombre, Integer edad,String placa,String codigotaxi){
            super(nombre, edad);
            this.placa= placa;
            this.codigotaxi= codigotaxi;
    }
    
    public CHOFER_BAQUERO(){};
    
    public void cedula(){
   Scanner entrada= new Scanner(System.in);
       int cedula;
       
       System.out.print("Numero cedula  ");
       cedula= entrada.nextInt();
       
       System.out.println("El numero de cedula es  " +cedula );
    }
    
    public void aceptarcarrera(){
    System.out.println("El Chofer acepta la carrera");
    }
    
    public void cancelarcarrera(){
    System.out.println("El chofer cancela la carrera");
    }
    
    public void placa(){
    Scanner entrada= new Scanner(System.in);
       String placa;
       
       System.out.print("La placa del taxi ");
       placa= entrada.next();
       
       System.out.println("El numero de placa es  " +placa );
    
    }
}
