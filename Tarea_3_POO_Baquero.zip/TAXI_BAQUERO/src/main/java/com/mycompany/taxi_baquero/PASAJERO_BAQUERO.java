
package com.mycompany.taxi_baquero;

import java.util.Scanner;

public class PASAJERO_BAQUERO extends PERSONA_BAQUERO{
 public Integer ci;
    public PASAJERO_BAQUERO(String nombre, Integer edad,Integer ci){
            super(nombre, edad);
            this.ci= ci;
    }
    
    public PASAJERO_BAQUERO(){};
    
    public void cedula(){
    Scanner entrada= new Scanner(System.in);
       int cedula;
       
       System.out.print("Numero de cedula  ");
       cedula= entrada.nextInt();
       
       System.out.println("El numero de cedula es  " +cedula );
    }
    
    public void pedirtaxi(){
    System.out.println("El pasajero solicita un taxi");
    }
    
    public void cancelartaxi(){
    System.out.println("El pasajero cancela al taxi");
    }
    
    
    


}
    
