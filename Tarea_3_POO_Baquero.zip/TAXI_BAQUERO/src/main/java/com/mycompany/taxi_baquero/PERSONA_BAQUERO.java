package com.mycompany.taxi_baquero;

abstract public class PERSONA_BAQUERO {
    public String nombre;
    public Integer edad;
    private Integer cedula;
    
    public PERSONA_BAQUERO(String nombre,Integer edad) {
        this.nombre= nombre;
        this.edad= edad;
    }
    
    public PERSONA_BAQUERO(){};

    public Integer getcedula(){
       return cedula;
       
    }
    public void setcedula(Integer cedula){
       this.cedula= cedula;
       
    }
    
    abstract public void cedula();
}

