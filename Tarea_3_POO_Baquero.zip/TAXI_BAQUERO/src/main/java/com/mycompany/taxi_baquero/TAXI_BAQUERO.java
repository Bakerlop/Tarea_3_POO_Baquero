
package com.mycompany.taxi_baquero;

import java.util.Scanner;

public class TAXI_BAQUERO {

    public static void main(String[] args) {
      Scanner entrada= new Scanner(System.in);
       String nombre;
       
       System.out.print("Nombre del pasajero  ");
       nombre= entrada.next();
       
       System.out.println("El pasajero se llama  " +nombre );
       
       PASAJERO_BAQUERO ob= new PASAJERO_BAQUERO();
       ob.cancelartaxi();
       ob.cedula();
       
       Scanner entradas= new Scanner(System.in);
       String nombre2;
       
       System.out.print("Nombre del Chofer  ");
       nombre2= entradas.next();
       
       System.out.println("El chofer se llama  " +nombre2 );
       CHOFER_BAQUERO placa= new CHOFER_BAQUERO();
       placa.aceptarcarrera();
       placa.cedula();
       placa.placa();
       
    }
}