package com.mycompany.codigo_baquero;

abstract public class ANIMALES_BAQUERO {
    public String nombre;
    private Integer edad;
    
    public ANIMALES_BAQUERO(String nombre){
       this.nombre=nombre;
    } 
    
    public ANIMALES_BAQUERO(){};
    
    public Integer getedad(){
      return edad;
    }
    
    public void setedad(Integer edad){
    this.edad= edad;
    }
    
      abstract public void hacerruido();
    
}