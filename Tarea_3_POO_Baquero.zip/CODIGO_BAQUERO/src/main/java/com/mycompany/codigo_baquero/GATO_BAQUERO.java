package com.mycompany.codigo_baquero;

import java.util.Scanner;

public class GATO_BAQUERO extends ANIMALES_BAQUERO{
    public String colordepelo;
    
    public GATO_BAQUERO(String nombre,String colordepelo){
    super(nombre);
    this.colordepelo=colordepelo;
    }
    
    public GATO_BAQUERO(){};
    
    public void hacerruido(){
    System.out.println("El gato dice miau");
    }
    
    public void trepaarboles(){
    System.out.println("El gato esta trepando arboles");
    }
    
    public void cazarratones(){
    Scanner entrada3= new Scanner(System.in);
       String cazarratones;
       
       System.out.print("Indique el gato esta cazando ratones ");
       cazarratones= entrada3.next();
       
       System.out.println("El gato " +cazarratones+ " esta cazando ratones ");
    }
    
}