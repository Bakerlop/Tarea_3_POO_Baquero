package com.mycompany.codigo_baquero;

public class CODIGO_BAQUERO{

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
