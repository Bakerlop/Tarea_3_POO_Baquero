package com.mycompany.codigo_baquero;

import java.util.Scanner;


public class PERRO_BAQUERO extends ANIMALES_BAQUERO{
    public String raza;
    
    public PERRO_BAQUERO(String nombre,String raza){
    super(nombre);
    this.raza= raza;
    }
    
    public PERRO_BAQUERO(){};
    
    public void hacerruido(){
    System.out.println("El perro esta ladrando");
    }
    
    public void jugando(){
    System.out.println("El perro esta jungando");
    }
    
    public void corriendo(){
    Scanner entrada4= new Scanner(System.in);
       String corriendo;
       
       System.out.print("Indique el perro que esta haciendo ");
       corriendo= entrada4.next();
       
       System.out.println("El perro " +corriendo+ " esta corriendo por la casa ");
    }
    
    public void raza(){
    Scanner entrada5= new Scanner(System.in);
       String raza;
       
       System.out.print("Indique la raza del perro ");
       raza= entrada5.next();
       
       System.out.println("El perro es de raza  " +raza);
    
    }
    
}